import { Component } from '@angular/core';

@Component({
    selector: 'es-landing',
    templateUrl: 'landingPage.component.html'
})

export class LandingPageComponent {

}
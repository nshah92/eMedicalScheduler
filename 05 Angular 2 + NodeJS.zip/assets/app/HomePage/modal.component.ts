import { Component } from '@angular/core';

@Component({
    selector: 'es-modal',
    templateUrl: 'modal.component.html'
})

export class ModalComponent {

}
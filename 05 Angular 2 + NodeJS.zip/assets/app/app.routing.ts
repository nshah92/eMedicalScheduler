import { Routes, RouterModule } from '@angular/router';

import { LandingPageComponent} from './HomePage/landingPage.component';
import { PatientRegComponent } from './patient/patientReg.component';

const APP_ROUTES: Routes = [
    { path: 'home', component: LandingPageComponent },
    { path: 'patient-registeration', component: PatientRegComponent },
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: '**', redirectTo: 'home', pathMatch: 'full' }
];

export const routing = RouterModule.forRoot(APP_ROUTES);